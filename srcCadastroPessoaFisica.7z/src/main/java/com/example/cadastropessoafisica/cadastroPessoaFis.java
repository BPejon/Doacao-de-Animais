package com.example.cadastropessoafisica;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class cadastroPessoaFis extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_pessoa_fis);
    }
}
