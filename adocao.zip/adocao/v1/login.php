<?php 

require_once dirname(__FILE__).'/../includes/DbOperations.php';
$response = array();

if($_SERVER['REQUEST_METHOD']=='POST'){

	//vendo se todos os parametros necessarios para se fazer o login
	if(
		isset($_POST['email']) AND isset($_POST['senha'])



	){
		$email = $_POST['email'];
		$senha = $_POST['senha'];
		
		$db = new DbOperations();

		$result = $db->loginDeUsuario($email, $senha);

		if($result != 0){
			$response['id_pessoa'] = $result;
			$response['error'] = false;
			$response['message'] = "Logado com sucesso.";
		}else{
			$response['error'] = true;
			$response['message'] = "E-Mail e/ou Senha incorretos.";

		}

	}else{

		$response['error'] = true;
		$response['message'] = "Esta faltando campos obrigatorios.";
	}

}else{

	$response['error'] = true;
	$response['message'] = "Tipo do RESQUEST deve ser POST.";
}


echo json_encode($response);

?>