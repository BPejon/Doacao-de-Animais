<?php 

require_once dirname(__FILE__).'/../includes/DbOperations.php';
$response = array();

if($_SERVER['REQUEST_METHOD']=='POST'){

	//vendo se todos os parametros necessarios para adicionar uma pessoa foram passados como POST
	if(
		isset($_POST['email']) AND isset($_POST['telefone']) AND isset($_POST['nome']) AND isset($_POST['uf']) AND isset($_POST['cidade']) AND
		isset($_POST['endereco']) AND isset($_POST['senha']) AND isset($_POST['cnpj']) AND isset($_POST['responsavel'])



	){
		//colocando os POST`s em variaveis
		$email = $_POST['email'];
		$telefone = $_POST['telefone'];
		$nome = $_POST['nome'];
		$uf = $_POST['uf'];
		$cidade = $_POST['cidade'];
		$endereco = $_POST['endereco'];
		$senha = $_POST['senha'];
		$cnpj = $_POST['cnpj'];
		$responsavel = $_POST['responsavel'];

		$db = new DbOperations();

		$result = $db->inserirJuridica($email, $telefone, $nome, $uf, $cidade, $endereco, $senha, $cnpj, $responsavel);

		//vendo o que se retorno da funcao inserir e setando a flag de erro e a mensagem em funcao disto.
		if($result == 0){
			$response['error'] = false;
			$response['message'] = "Usuario adicionado com sucesso.";
		}else if($result == 1){
			$response['error'] = true;
			$response['message'] = "Problema ao criar a conta, tente mais tarde.";
		}else if($result == 2){
			$response['error'] = true;
			$response['message'] = "Já existe uma conta com este E-Mail e este CNPJ.";

		}else if($result == 3){
			$response['error'] = true;
			$response['message'] = "Já existe uma conta com este E-Mail.";
		}else{
			$response['error'] = true;
			$response['message'] = "Já existe uma conta com este CNPJ";
		}


	}else{
		$response['error'] = true;
		$response['message'] = "Esta faltando campos obrigatorios.";
	}

}else{

	$response['error'] = true;
	$response['message'] = "Tipo do RESQUEST deve ser POST.";
}


echo json_encode($response);

?>