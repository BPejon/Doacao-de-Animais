<?php 


require_once dirname(__FILE__).'/../includes/DbOperations.php';
require_once dirname(__FILE__).'/../includes/Util.php';
$response = array();

if($_SERVER['REQUEST_METHOD']=='POST'){


		//vendo se todos os parametros necessarios para adicionar uma pessoa foram passados como POST
	if(
		isset($_POST['nome']) AND isset($_POST['especie']) AND isset($_POST['descricao']) AND isset($_POST['sexo']) AND 
		isset($_POST['idade']) AND	isset($_POST['raca']) AND isset($_POST['condicao']) AND isset($_POST['image']) AND
		isset($_POST['id_pessoa'])

	){
		//colocando em variaveis os parametros vindos do POST
		$nome = $_POST['nome'];
		$especie = $_POST['especie'];
		$descricao = $_POST['descricao'];
		$sexo = $_POST['sexo'];
		$idade = $_POST['idade'];
		$raca = $_POST['raca'];
		$condicao = $_POST['condicao'];
		$id_pessoa = $_POST['id_pessoa'];

		//imagem deve ser passada como base64_encode
		$image = $_POST['image'];

		//criando o nome para a imagem
		$size = 60;
		$image_name = Util::randString($size);
		$image_name .= '.jpg';


		//criando o path para a imagem
		$path = dirname(__FILE__).'\..\images\\'.$image_name;

		//inserindo a instancia no banco de dados
		$db = new DbOperations();

		$result = $db->inserirAnimal($nome, $especie, $descricao, $sexo, $idade, $raca, $image_name, $id_pessoa, $condicao);

		if($result == 0){

			//esta linha adiciona a imagem ao webServer, colocando-a na pasta de images
			file_put_contents($path, base64_decode($image));

			$response['error'] = false;
			$response['message'] = "Animal adicionado para adocao.";
		}else{
			$response['error'] = true;
			$response['message'] = "Erro ao adicionar animal para adocao.";
		}


	}else{
		$response['error'] = true;

		$response['message'] = "Esta faltando campos obrigatorisadasdos.";


		
	}


}else{

	$response['error'] = true;
	$response['message'] = "Tipo do RESQUEST deve ser POST.";
}

echo json_encode($response);


?>