<?php 

require_once dirname(__FILE__).'/../includes/DbOperations.php';
$response = array();

if($_SERVER['REQUEST_METHOD']=='POST'){

	//vendo se todos os parametros necessarios para se fazer o login
	if(
		isset($_POST['id_pessoa'])



	){
		$id_pessoa = $_POST['id_pessoa'];

		
		$db = new DbOperations();

		$result = $db->listarAnimaisdeUmaPessoa($id_pessoa);

		if($result != false){
			$i = 0;
			//adicionando os animais encontrados no array $response, cada animal encontrado entra com a chave do indice dele no vetor
			foreach ($result as $value) {

				$response[ $i ] = $value;
				$i += 1; 
			}

			$response['num'] = $i;

			$response['error'] = false;
			$response['message'] = "Achou um animal com este Id.";

		}else{
			
			$response['error'] = false;
			$response['num'] = 0;
			$response['message'] = "Nao foi achado nenhum animal cadastrado por esta pessoa.";

		}

	}else{

		$response['error'] = true;
		$response['message'] = "Esta faltando campos obrigatorios.";
	}

}else{

	$response['error'] = true;
	$response['message'] = "Tipo do RESQUEST deve ser POST.";
}


echo json_encode($response);

?>