<?php 

require_once dirname(__FILE__).'/../includes/DbOperations.php';
$response = array();

if($_SERVER['REQUEST_METHOD']=='POST'){

	$db = new DbOperations();

	$result = $db->listarAnimais();

	if($result != false){

		$i = 0;
		//adicionando os animais encontrados no array $response, cada animal encontrado entra com a chave do indice dele no vetor
		foreach ($result as $value) {

			$response[ $i ] = $value ;
			$i += 1; 
		}

		$response['num'] = $i;

		$response['error'] = false;
		$response['message'] = "Achou um animal.";


	}else{
		$response['error'] = false;
		$response['num'] = 0;
		$response['message'] = "Nao foi achado nenhum animal.";
	}

}else{

	$response['error'] = true;
	$response['message'] = "Tipo do RESQUEST deve ser POST.";
}


echo json_encode($response);

?>