<?php 

require_once dirname(__FILE__).'/../includes/DbOperations.php';
$response = array();

if($_SERVER['REQUEST_METHOD']=='POST'){

	//vendo se todos os parametros necessarios para buscar um animal
	if(
		isset($_POST['id_animal'])

	){
		$id_animal = (int)$_POST['id_animal'];

		$db = new DbOperations();

		$result = $db->buscarAnimal($id_animal);

		if($result != false){
			//setando os valores recebidos por result para o array de response
			$response['id_animal'] = $result['id_animal'];
			$response['nome'] = $result['nome'];
			$response['especie'] = $result['especie'];
			$response['descricao'] = $result['descricao'];
			$response['sexo'] = $result['sexo'];
			$response['idade'] = $result['idade'];
			$response['raca'] = $result['raca'];
			$response['image_name'] = $result['image_name'];
			$response['condicao'] = $result['condicao'];

			$response['id_pessoa'] = $result['id_pessoa'];
			$response['email'] = $result['email'];
			$response['telefone'] = $result['telefone'];
			$response['nome_dono'] = $result['nome_dono'];
			$response['uf'] = $result['uf'];
			$response['cidade'] = $result['cidade'];
			$response['endereco'] = $result['endereco'];

			$response['id_fisica'] = $result['id_fisica'];
			$response['cpf'] = $result['cpf'];

			$response['id_juridica'] = $result['id_juridica'];
			$response['cnpj'] = $result['cnpj'];
			$response['responsavel'] = $result['responsavel'];


 			$response['error'] = false;
			$response['message'] = "Achou um animal com este Id.";

		}else{
			$response['error'] = true;
			$response['message'] = "Náo existe um animal com este ID.";
		}

	}else{
		$response['error'] = true;
		$response['message'] = "Esta faltando campos obrigatorios.";
	}

}else{

	$response['error'] = true;
	$response['message'] = "Tipo do RESQUEST deve ser POST.";
}


echo json_encode($response);

?>