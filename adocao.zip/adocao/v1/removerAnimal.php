<?php 

require_once dirname(__FILE__).'/../includes/DbOperations.php';
$response = array();

if($_SERVER['REQUEST_METHOD']=='POST'){

	//vendo se todos os parametros necessarios para se fazer o login
	if(
		isset($_POST['id_animal'])



	){
		$id_animal = $_POST['id_animal'];
		
		$db = new DbOperations();

		$result = $db->removerAnimal($id_animal);

		if($result == 0){
			$response['error'] = false;
			$response['message'] = "Removido com sucesso.";
		}else{
			$response['error'] = true;
			$response['message'] = "Erro ao remover o animal, tente mais tarde.";

		}

	}else{

		$response['error'] = true;
		$response['message'] = "Esta faltando campos obrigatorios.";
	}

}else{

	$response['error'] = true;
	$response['message'] = "Tipo do RESQUEST deve ser POST.";
}


echo json_encode($response);

?>