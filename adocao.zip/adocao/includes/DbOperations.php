<?php 

	class DbOperations{


		private $con;

		//metodo construtor da classe
		function __construct(){
			require_once dirname(__FILE__).'/DbConnect.php';

			$db = new DbConnect;

			$this->con = $db->connect();

		}

		//so fecha a conexao com o bando de dados
		function __destruct(){
			$this->con->close();
		}

		private function existeEmail($email){
			//soh faz a query ao bando de dados procurando por alguem que tenha este email
			$stmt = $this->con->prepare(" SELECT id_pessoa FROM  pessoas WHERE email = ?");
			$stmt->bind_param("s", $email);
			$stmt->execute();
			$stmt->store_result();

			//se acho algum com o email passado, retorna true, retorna false caso contrario
			if($stmt->num_rows > 0){	
				$stmt->close();
				return true;
			}else{
				$stmt->close();
				return false;
			}
		}


		private function existeCPF($cpf){
			//soh faz a query ao bando de dados procurando por alguem que tenha este cpf
			$stmt = $this->con->prepare(" SELECT id_fisica FROM  fisicas WHERE cpf = ?");
			$stmt->bind_param("s", $cpf);
			$stmt->execute();
			$stmt->store_result();
			
			//se acho algum com o cpf passado, retorna true, retorna false caso contrario
			if($stmt->num_rows > 0){
				$stmt->close();
				return true;
			}else{
				$stmt->close();
				return false;
			}
		}

		private function existeCNPJ($cnpj){
			//soh faz a query ao bando de dados procurando por alguem que tenha este cnpj
			$stmt = $this->con->prepare(" SELECT id_juridica FROM  juridicas WHERE cnpj = ?");
			$stmt->bind_param("s", $cnpj);
			$stmt->execute();
			$stmt->store_result();
			
			//se acho algum com o cnpj passado, retorna true, retorna false caso contrario
			if($stmt->num_rows > 0){
				$stmt->close();
				return true;
			}else{
				$stmt->close();
				return false;
			}
		}

		//insere uma pessoa fisica no banco de dados, mas especificamente na tabela de fisicas e na tabela de pessoas no db
		public function inserirFisica($email, $telefone, $nome, $uf, $cidade, $endereco, $senha, $cpf){


			$exEmail = $this->existeEmail($email);
			$exCPF = $this->existeCPF($cpf);

			//se nao existir mais alguem com este cpf ou este email
			if(  !$exCPF && !$exEmail ){

				//inserindo na tabela de pessoas fisicas primeiro
				$stmt = $this->con->prepare(" INSERT INTO fisicas(cpf) VALUES(?);");
				$stmt->bind_param("s", $cpf);

				//executa o comando, o if eh para ver se nao conseguiu executar o comando
				if( !$stmt->execute() ){
					$stmt->close();
					return 1;
				}	

				$stmt->reset();

				//agora vamos recuperar o id_fisica da pessoa criada pelo INSERT INTO
				$stmt = $this->con->prepare("SELECT id_fisica FROM fisicas WHERE cpf = ?");
				$stmt->bind_param("s", $cpf);

				$stmt->execute();

				$res = $stmt->get_result();

				$id_fisica = $res->fetch_assoc()['id_fisica'];

				$stmt->close();

				//encriptografando a senha
				$senha_enc = md5($senha);

				//inserindo na tabela de pessoas
				$stmt = $this->con->prepare("INSERT INTO pessoas(email,telefone, nome, uf, cidade, endereco, senha, id_fisica) VALUES (?,?,?,?,?,?,?,?)");
				$stmt->bind_param("ssssssss", $email, $telefone, $nome, $uf, $cidade, $endereco, $senha_enc, $id_fisica);

				if( $stmt->execute() ){
					$stmt->close();
					return 0;
				}else{
					$stmt->close();
					return 1;
				}

			}else{

				//so pra ver qual mensagem de erro deve ser printada
				if($exEmail && $exCPF){
					return 2;

				}else if($exEmail){
					return 3;
				}else{
					return 4;
				}

			}


		}

		//insere uma pessoa juridica no banco de dados, mas especificamente na tabela de juridicas e na tabela de pessoas no db
		public function inserirJuridica($email, $telefone, $nome, $uf, $cidade, $endereco, $senha, $cnpj, $responsavel){


			$exEmail = $this->existeEmail($email);
			$exCNPJ = $this->existeCNPJ($cnpj);

			//se nao existir mais alguem com este cnpj ou este email
			if(  !$exCNPJ && !$exEmail ){

				//inserindo na tabela de pessoas juridicas primeiro
				$stmt = $this->con->prepare(" INSERT INTO juridicas(cnpj, responsavel) VALUES(?, ?)");
				$stmt->bind_param("ss", $cnpj, $responsavel);

				//executa o comando, o if eh para ver se nao conseguiu executar o comando
				if( !$stmt->execute() ){
					$stmt->close();
					return 1;
				}

				$stmt->close();



				//agora vamos recuperar o id_juridica da ong criada pelo INSERT INTO
				$stmt = $this->con->prepare("SELECT id_juridica	 FROM juridicas WHERE cnpj = ?");
				$stmt->bind_param("s", $cnpj);

				$stmt->execute();

				$id_juridica = (int)$stmt->get_result()->fetch_assoc()['id_juridica'];

				$stmt->close();

				//encriptografando a senha
				$senha_enc = md5($senha);

				//inserindo na tabela de pessoas
				$stmt = $this->con->prepare("INSERT INTO pessoas(email,telefone, nome, uf, cidade, endereco, senha, id_juridica) VALUES (?,?,?,?,?,?,?,?)");
				$stmt->bind_param("ssssssss", $email, $telefone, $nome, $uf, $cidade, $endereco, $senha_enc, $id_juridica);

				if( $stmt->execute() ){
					$stmt->close();
					return 0;
				}else{
					$stmt->close();
					return 1;
				}

			}else{

				//so pra ver qual mensagem de erro deve ser printada
				if($exEmail && $exCNPJ){
					return 2;

				}else if($exEmail){
					return 3;
				}else{
					return 4;
				}

			}


		}

		//insere um animal no banco de dados
		public function inserirAnimal($nome, $especie, $descricao, $sexo, $idade, $raca, $image_name, $id_pessoa, $condicao){

			//como nao tem que tratar repeticao para o animal, e so fazer o INSERT INTO e ver se deu certo
			$stmt = $this->con->prepare("INSERT INTO animais(nome, especie, descricao, sexo, idade, raca, image_name, id_pessoa,condicao) VALUES(?,?,?,?,?,?,?,?,?)");
			$stmt->bind_param("sssssssss", $nome, $especie, $descricao, $sexo, $idade, $raca, $image_name, $id_pessoa, $condicao);

			if( $stmt->execute() ){
				$stmt->close();
				return 0;
			}else{
				$stmt->close();
				return 1;
			}

		}

		//atualiza todos os campos possiveis de um animal pelos passados como parametro
		public function atualizarAnimal($id_animal, $nome, $especie, $descricao, $sexo, $idade, $raca, $image_name, $condicao){

			$stmt = $this->con->prepare("UPDATE animais SET nome = ?, especie = ?, descricao = ?, sexo = ?, idade = ?, raca = ?, image_name = ?, condicao = ? WHERE id_animal = ?");
			$stmt->bind_param("sssssssss", $nome, $especie, $descricao, $sexo, $idade, $raca, $image_name, $condicao, $id_animal);


			if( $stmt->execute() ){
				$stmt->close();
				return 0;
			}else{
				$stmt->close();
				return 1;

			}
		}

		//remove um animal pelo seu id do banco de dados
		public function removerAnimal($id_animal){
			$stmt = $this->con->prepare("DELETE FROM animais WHERE id_animal = ?");
			$stmt->bind_param("s", $id_animal);

			if( $stmt->execute() ){
				$stmt->close();
				return 0;
			}else{
				$stmt->close();
				return 1;
			}
		}

		//busca as informacoes de um animal pelo seu id, pega as informacoes do seu dono tbm
		public function buscarAnimal($id_animal){

			$stmt = $this->con->prepare(" SELECT an.id_animal, an.nome, an.especie, an.descricao, an.sexo, an.idade, an.raca, an.image_name,
												an.condicao,
												p.id_pessoa, p.email, p.telefone, p.nome as nome_dono, p.uf, p.cidade, p.endereco, p.senha,
										        f.id_fisica, f.cpf,
										        j.id_juridica, j.cnpj, j.responsavel
										FROM animais AS an 
										INNER JOIN pessoas AS p ON an.id_pessoa = p.id_pessoa 
										LEFT JOIN fisicas AS f ON p.id_fisica = f.id_fisica
										LEFT JOIN juridicas AS j ON p.id_juridica = p.id_juridica
										WHERE an.id_animal = ?");



			$stmt->bind_param("s", $id_animal);

			$stmt->execute();

			$result = $stmt->get_result();



			$stmt->close();

			if( $result->num_rows > 0 ){
				$res = $result->fetch_assoc();

				//passando os id null para -1 para ser um campo inteiro
				if($res['id_fisica'] == null){
					$res['id_fisica'] = -1;
				}

				if($res['id_juridica'] == null){
					$res['id_juridica'] = -1;
				}

				return $res;
			}else{

				return false;


			}


		}

		//busca as informacoes de um animal, mas so apenas as que estao na tabela animais
		public function buscarSoAnimal($id_animal){

			$stmt = $this->con->prepare(" SELECT * FROM  animais WHERE id_animal = ?");
			$stmt->bind_param("s", $id_animal);
			$stmt->execute();
			
			$result = $stmt->get_result();

			$stmt->close();

			//se encontrou um animal com este id, retorna os dados dele, caso contrario retorna false
			if($result->num_rows > 0){	
				
				return $result->fetch_assoc();
			}else{
				return false;
			}

		}

		//retorna todos os animais para doacao
		public function listarAnimais(){
			$stmt = $this->con->prepare(" SELECT an.id_animal, an.nome, an.especie, an.descricao, an.sexo, an.idade, an.raca, an.image_name,
												an.condicao,
												p.id_pessoa, p.email, p.telefone, p.nome as nome_dono, p.uf, p.cidade, p.endereco, p.senha,
										        f.id_fisica, f.cpf,
										        j.id_juridica, j.cnpj, j.responsavel
										FROM animais AS an 
										INNER JOIN pessoas AS p ON an.id_pessoa = p.id_pessoa 
										LEFT JOIN fisicas AS f ON p.id_fisica = f.id_fisica
										LEFT JOIN juridicas AS j ON p.id_juridica = p.id_juridica
										WHERE an.condicao != 'Reservado'");

			$stmt->execute();

			$res = $stmt->get_result();


			if($res->num_rows > 0){
				$results = array();
				while($row = $res->fetch_assoc()){
					//passando os id null para -1 para ser um campo inteiro
					if($row['id_fisica'] == null){
						$row['id_fisica'] = -1;
					}

					if($row['id_juridica'] == null){
						$row['id_juridica'] = -1;
					}
					$results[] = $row;
				}
				$stmt->close();
				return $results;
			}else{
				$stmt->close();
				return false;
			}
			

		}

		//retorna todos os animais para doacao que foram cadastrados pelo id_pessoa passado como parametro
		public function listarAnimaisdeUmaPessoa($id_pessoa){
			$stmt = $this->con->prepare(" SELECT an.id_animal, an.nome, an.especie, an.descricao, an.sexo, an.idade, an.raca, an.image_name,
												an.condicao,
												p.id_pessoa, p.email, p.telefone, p.nome as nome_dono, p.uf, p.cidade, p.endereco, p.senha,
										        f.id_fisica, f.cpf,
										        j.id_juridica, j.cnpj, j.responsavel
										FROM animais AS an 
										INNER JOIN pessoas AS p ON an.id_pessoa = p.id_pessoa 
										LEFT JOIN fisicas AS f ON p.id_fisica = f.id_fisica
										LEFT JOIN juridicas AS j ON p.id_juridica = p.id_juridica
										WHERE p.id_pessoa = ?");
			$stmt->bind_param("s", $id_pessoa);

			$stmt->execute();

			$res = $stmt->get_result();


			if($res->num_rows > 0){
				$results = array();
				while($row = $res->fetch_assoc()){
					//passando os id null para -1 para ser um campo inteiro
					if($row['id_fisica'] == null){
						$row['id_fisica'] = -1;
					}

					if($row['id_juridica'] == null){
						$row['id_juridica'] = -1;
					}
					$results[] = $row;
				}
				$stmt->close();
				return $results;
			}else{

				$stmt->close();
				return false;
			}
			

		}

		//funcao para logar um usuario, retorna o id do usuario caso exista um usuario com o par email-senha passado como parametro, 0 caso contrario
		public function loginDeUsuario($email, $senha){

			$senha_enc = md5($senha);

			$stmt = $this->con->prepare("SELECT id_pessoa FROM pessoas WHERE email = ? AND senha = ?");
			$stmt->bind_param("ss", $email, $senha_enc);

			$stmt->execute();

			$res = $stmt->get_result();

			if( $res->num_rows > 0 ){

				$result = $res->fetch_assoc();
				$stmt->close();
				return $result['id_pessoa'];

			}else{
				return 0;
			}
		}

		
	}	

?>