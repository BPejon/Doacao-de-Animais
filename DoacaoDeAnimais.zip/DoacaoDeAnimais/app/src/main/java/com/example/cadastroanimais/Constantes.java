package com.example.cadastroanimais;

public class Constantes {
    private static final String ROOT_URL = "http://192.168.43.59/adocao/";
    public static final String ROOT_V= ROOT_URL+"v1/";
    public static final String URL_IMAGEM = ROOT_URL+"images/";

    public static final String URL_LOGIN = ROOT_V+"login.php";

}
