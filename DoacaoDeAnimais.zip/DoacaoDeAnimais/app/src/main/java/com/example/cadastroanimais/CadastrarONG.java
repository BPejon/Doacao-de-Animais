package com.example.cadastroanimais;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CadastrarONG extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_ong);
    }
}
