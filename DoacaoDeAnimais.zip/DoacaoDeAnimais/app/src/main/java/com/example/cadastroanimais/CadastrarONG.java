package com.example.cadastroanimais;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Spinner;

public class CadastrarONG extends AppCompatActivity {


    EditText CNPJ, NomeONG, Email, Telefone, NomeResp, Endereco, Cidade, Senha, ConfirmarSenha;
    Spinner spinnerEstado;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_ong);

        CNPJ = (EditText) findViewById(R.id.set_cnpj);
        NomeONG = (EditText) findViewById(R.id.set_nome);
        Email = (EditText) findViewById(R.id.set_email);
        Telefone = (EditText) findViewById(R.id.set_telefone);
        NomeResp = (EditText) findViewById(R.id.set_nome_resp);
        Endereco = (EditText) findViewById(R.id.set_endereco);
        Cidade = (EditText) findViewById(R.id.set_cidade);
        Senha = (EditText) findViewById(R.id.set_senha);
        ConfirmarSenha = (EditText) findViewById(R.id.set_confirma_senha);

        spinnerEstado= findViewById(R.id.spinner_estado);





    }

    private void ValidaCadastro(){
        String nomeONG;
        String email;

    }
}
