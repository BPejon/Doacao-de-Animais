package com.example.cadastroanimais;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

public class EditarCadastroAnimal extends AppCompatActivity {

    ImageView imagemAnimal;
    EditText setIdade, setNome, setBreveDescricao;
    Button botaoFinalizar, botaoEditar;
    Spinner spinnerEspecie, spinnerSexo, spinnerCondicao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_cadastro_animal);



        //Intent intent  = getIntent();

        spinnerCondicao = (Spinner) findViewById(R.id.spinnerCondicaoanimal);
        spinnerEspecie = (Spinner) findViewById(R.id.spinnerEspecieAnimal);
        spinnerSexo = (Spinner) findViewById(R.id.spinnerSexoAnimal);

        botaoEditar = (Button) findViewById(R.id.botaoeEditar);
        botaoFinalizar = (Button) findViewById(R.id.botaoFinalizarInscricao);

        setIdade = (EditText) findViewById(R.id.setIdade);
        setNome = (EditText) findViewById(R.id.setNomeAnimal);
        setBreveDescricao = (EditText) findViewById(R.id.setBreveDescricao);

        imagemAnimal = (ImageView) findViewById(R.id.imagemAnimal);




        //CARREGAR O NOME DO ANIMAL
        String texto = "texto a ser colocado e editado";
        setNome.setText(texto);

        //CARREGA A IDADE DO ANIMAL
        String numero = "adasd";
        setIdade.setText(numero);

        //CARREGAR BREVE DESCRICAO DO ANIMAL
        String breve = "Ele é gordo e fofo!!";
        setBreveDescricao.setText(breve);
    }
}
